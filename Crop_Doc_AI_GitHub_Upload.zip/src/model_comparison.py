"""Compare a transfer-learning CNN with classical models on leaf images.

Expected data layout:
data_dir/
  train/<class_name>/*.jpg
  val/<class_name>/*.jpg
  test/<class_name>/*.jpg

This script is an educational starter, not a validated agricultural diagnostic tool.
"""
import argparse
import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    ConfusionMatrixDisplay, confusion_matrix
)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

IMG_SIZE = (224, 224)
BATCH_SIZE = 32
SEED = 42


def load_split(path, shuffle):
    ds = tf.keras.utils.image_dataset_from_directory(
        path,
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        label_mode="int",
        shuffle=shuffle,
        seed=SEED if shuffle else None,
    )
    return ds


def collect_embeddings(dataset, feature_model):
    features, labels = [], []
    for images, batch_labels in dataset:
        images = tf.keras.applications.mobilenet_v2.preprocess_input(
            tf.cast(images, tf.float32)
        )
        emb = feature_model(images, training=False).numpy()
        features.append(emb.reshape((emb.shape[0], -1)))
        labels.append(batch_labels.numpy())
    return np.concatenate(features), np.concatenate(labels)


def evaluate(name, y_true, y_pred, elapsed, output_dir, class_names):
    scores = {
        "model": name,
        "accuracy": accuracy_score(y_true, y_pred),
        "precision_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "prediction_seconds": elapsed,
    }
    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(class_names))))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=class_names)
    fig, ax = plt.subplots(figsize=(max(7, len(class_names) * 0.8), max(6, len(class_names) * 0.7)))
    disp.plot(ax=ax, xticks_rotation=45, colorbar=False)
    ax.set_title(f"Confusion Matrix — {name}")
    fig.tight_layout()
    safe_name = name.lower().replace(" ", "_")
    fig.savefig(os.path.join(output_dir, f"confusion_matrix_{safe_name}.png"), dpi=150)
    plt.close(fig)
    return scores


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", default="data/leaf_images")
    parser.add_argument("--output_dir", default="results")
    parser.add_argument("--epochs", type=int, default=5)
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)

    train_dir = os.path.join(args.data_dir, "train")
    val_dir = os.path.join(args.data_dir, "val")
    test_dir = os.path.join(args.data_dir, "test")
    for p in (train_dir, val_dir, test_dir):
        if not os.path.isdir(p):
            raise FileNotFoundError(
                f"Missing {p}. See data/README.md for the required folder layout."
            )

    train_ds = load_split(train_dir, shuffle=True)
    val_ds = load_split(val_dir, shuffle=False)
    test_ds = load_split(test_dir, shuffle=False)
    class_names = train_ds.class_names
    if val_ds.class_names != class_names or test_ds.class_names != class_names:
        raise ValueError("Train, val, and test folders must contain the same class folders.")

    # Transfer-learning CNN: freeze pretrained feature layers for the starter run.
    base = tf.keras.applications.MobileNetV2(
        input_shape=(*IMG_SIZE, 3), include_top=False, weights="imagenet", pooling="avg"
    )
    base.trainable = False
    inputs = tf.keras.Input(shape=(*IMG_SIZE, 3))
    x = tf.keras.applications.mobilenet_v2.preprocess_input(inputs)
    x = base(x, training=False)
    x = tf.keras.layers.Dropout(0.2)(x)
    outputs = tf.keras.layers.Dense(len(class_names), activation="softmax")(x)
    cnn = tf.keras.Model(inputs, outputs)
    cnn.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=2, restore_best_weights=True
        )
    ]
    cnn.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=callbacks, verbose=1)

    rows = []
    start = time.perf_counter()
    cnn_probs = cnn.predict(test_ds, verbose=0)
    cnn_elapsed = time.perf_counter() - start
    y_test = np.concatenate([y.numpy() for _, y in test_ds])
    rows.append(evaluate(
        "Transfer Learning CNN", y_test, np.argmax(cnn_probs, axis=1),
        cnn_elapsed, args.output_dir, class_names
    ))

    # Classical algorithms use embeddings from the same pretrained image backbone.
    feature_model = tf.keras.Model(inputs=base.input, outputs=base.output)
    x_train, y_train = collect_embeddings(load_split(train_dir, shuffle=False), feature_model)
    x_val, y_val = collect_embeddings(val_ds, feature_model)
    x_test, y_test_features = collect_embeddings(test_ds, feature_model)

    classical = {
        "SVM": make_pipeline(StandardScaler(), SVC(kernel="rbf", class_weight="balanced")),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, class_weight="balanced", random_state=SEED, n_jobs=-1
        ),
        "KNN": make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5)),
    }
    # Validation split is loaded for explicit methodology/data sanity; final scoring uses test only.
    print(f"Classes: {class_names}; validation examples: {len(y_val)}")
    for name, model in classical.items():
        model.fit(x_train, y_train)
        start = time.perf_counter()
        pred = model.predict(x_test)
        elapsed = time.perf_counter() - start
        rows.append(evaluate(name, y_test_features, pred, elapsed, args.output_dir, class_names))

    out = os.path.join(args.output_dir, "metrics.csv")
    pd.DataFrame(rows).to_csv(out, index=False)
    print(f"Saved evaluation metrics to {out}")
    print("Reminder: scores are dataset-specific and should be interpreted with expert review.")


if __name__ == "__main__":
    main()
