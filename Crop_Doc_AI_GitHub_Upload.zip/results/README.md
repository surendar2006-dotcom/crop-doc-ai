# Results

No measured results are included yet. Run `src/model_comparison.py` on a valid labelled dataset to generate `metrics.csv` and confusion-matrix plots here. Do not invent or manually estimate model scores.
