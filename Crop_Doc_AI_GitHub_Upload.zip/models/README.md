# Models

Trained model files are not included. After training, the experiment script saves metrics and confusion matrices under `results/`. If you later save model files here, check file size and GitHub's file limits before committing them.
