# Crop Doc AI — Plant Disease Detection

**YUVA Internship · Week 2: AI Algorithm Selection and Methodology Formulation**

Crop Doc AI is a learning project that explores how machine-learning algorithms can classify plant leaf images into disease categories. This repository contains the project methodology, an experiment script, and the Week 2 report.

> **Important:** This repository is a starter implementation. No trained model, real evaluation results, or crop-disease diagnosis claims are included. Add a properly licensed, labelled dataset and run the experiments before reporting measured performance.

## Project objectives

- Compare a transfer-learning CNN with classical classifiers (SVM, Random Forest, and KNN).
- Evaluate models using accuracy, precision, recall, macro F1-score, and a confusion matrix.
- Record model performance in a reproducible way.
- Document limitations and responsible-use considerations.

## Repository structure

```text
Crop_Doc_AI_GitHub_Project/
├── README.md
├── requirements.txt
├── .gitignore
├── docs/
│   └── YUVA_Week2_AI_Algorithm_Selection_Crop_Doc_AI.docx
├── data/
│   └── README.md
├── src/
│   └── model_comparison.py
├── models/
│   └── README.md
└── results/
    └── README.md
```

## Dataset setup

Use a labelled dataset that you are permitted to use. Arrange it like this:

```text
data/leaf_images/
├── train/
│   ├── Healthy/
│   ├── Disease_A/
│   └── Disease_B/
├── val/
│   ├── Healthy/
│   ├── Disease_A/
│   └── Disease_B/
└── test/
    ├── Healthy/
    ├── Disease_A/
    └── Disease_B/
```

Each class folder should contain images for that class. Replace the example class names with your real dataset classes. Keep the test set separate until final evaluation. Do not upload private, restricted, or unlicensed images to GitHub.

## Setup

Python 3.10 or 3.11 is recommended.

```bash
python -m venv .venv
```

Activate the environment, then install dependencies:

```bash
pip install -r requirements.txt
```

## Run the experiment

After you have created the dataset folders above:

```bash
python src/model_comparison.py --data_dir data/leaf_images --output_dir results
```

The script trains a MobileNetV2 transfer-learning classifier and compares SVM, Random Forest, and KNN using MobileNetV2 image embeddings. It saves a metrics CSV and confusion-matrix images in `results/`. Training may take a while and benefits from a GPU.

## Methodology

1. Collect labelled leaf images and check data quality and class balance.
2. Separate training, validation, and test data to avoid data leakage.
3. Resize images and apply model-specific preprocessing.
4. Train a transfer-learning CNN using training images and validation-based early stopping.
5. Extract CNN embeddings and train SVM, Random Forest, and KNN comparison models.
6. Evaluate all approaches on the same held-out test set.
7. Compare accuracy, macro precision, macro recall, macro F1, training time, and inference time.
8. Inspect incorrect predictions and document limitations.

## Responsible use

Predictions are experimental and must not be treated as a confirmed agricultural diagnosis. Image quality, field conditions, mixed infections, and visually similar symptoms can affect results. Seek qualified agricultural advice before making treatment decisions.

## Week 2 report

See `docs/YUVA_Week2_AI_Algorithm_Selection_Crop_Doc_AI.docx` for the algorithm review, comparison framework, recommendation, methodology, limitations, and references.

## Suggested GitHub repository description

`Crop leaf disease classification study comparing CNN transfer learning, SVM, Random Forest, and KNN for the YUVA Week 2 AI methodology task.`
