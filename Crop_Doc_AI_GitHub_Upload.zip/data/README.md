# Dataset folder

The dataset is not bundled with this repository. Obtain a plant-leaf image dataset that you are legally permitted to use, then create:

```text
data/leaf_images/
├── train/<class_name>/*.jpg
├── val/<class_name>/*.jpg
└── test/<class_name>/*.jpg
```

Use the same class names in all three splits. Avoid near-duplicate images across splits and keep the test split untouched until final evaluation. Update this file with the dataset name, source URL, licence, and class list after selecting your dataset.
